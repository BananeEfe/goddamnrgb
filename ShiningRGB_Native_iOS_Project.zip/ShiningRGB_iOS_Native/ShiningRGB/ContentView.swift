import SwiftUI
import CoreBluetooth
import UIKit

@main
struct ShiningRGBApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
                .preferredColorScheme(.dark)
        }
    }
}

enum StudioTab: String, CaseIterable {
    case home = "Home", colors = "Colors", animations = "Animations", diy = "DIY"
    var icon: String {
        switch self {
        case .home: return "house.fill"
        case .colors: return "paintpalette.fill"
        case .animations: return "sparkles"
        case .diy: return "textformat"
        }
    }
}

struct ContentView: View {
    @State private var tab: StudioTab = .home
    @State private var selectedColor = Color(red: 0.55, green: 0.35, blue: 0.96)
    @State private var brightness = 0.8
    @State private var speed = 0.5
    @State private var selectedEffect = "Static"
    @State private var customText = "YOUR TEXT"
    @StateObject private var bluetooth = BluetoothManager()

    private let palette: [Color] = [
        Color(hex: "8B5CF6"), Color(hex: "FF3B73"), Color(hex: "FF7A32"),
        Color(hex: "FFD43B"), Color(hex: "45E6A8"), Color(hex: "39D9FF"),
        Color(hex: "4C7DFF"), .white
    ]

    var body: some View {
        ZStack {
            LinearGradient(colors: [Color(hex: "211A3B"), Color(hex: "090A10"), Color(hex: "090A10")],
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()
            VStack(spacing: 0) {
                header
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 22) {
                        switch tab {
                        case .home: homePage
                        case .colors: colorsPage
                        case .animations: animationsPage
                        case .diy: diyPage
                        }
                    }
                    .padding(.horizontal, 18)
                    .padding(.top, 8)
                    .padding(.bottom, 24)
                }
                tabBar
            }
        }
        .tint(Color(hex: "B89AFF"))
        .alert("Bluetooth device", isPresented: $bluetooth.showAlert) {
            Button("OK", role: .cancel) { }
        } message: {
            Text(bluetooth.alertMessage)
        }
    }

    private var header: some View {
        HStack(spacing: 11) {
            ZStack {
                RoundedRectangle(cornerRadius: 14).fill(
                    LinearGradient(colors: [Color(hex: "9B5CFF"), Color(hex: "3CE8E1")],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                Image(systemName: "sparkle").font(.system(size: 22, weight: .bold)).foregroundStyle(.white)
            }
            .frame(width: 43, height: 43)
            VStack(alignment: .leading, spacing: 3) {
                Text("ShiningRGB").font(.system(size: 18, weight: .bold))
                Text("LIGHT STUDIO").font(.system(size: 10, weight: .medium)).tracking(2).foregroundStyle(.secondary)
            }
            Spacer()
            Button { bluetooth.startScan() } label: {
                Image(systemName: "dot.radiowaves.left.and.right")
                    .font(.system(size: 17, weight: .semibold))
                    .frame(width: 42, height: 42)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 14))
            }
        }
        .padding(.horizontal, 18).padding(.top, 8).padding(.bottom, 15)
    }

    private var connectionCard: some View {
        HStack(spacing: 10) {
            Circle().fill(bluetooth.isScanning ? .green : Color(hex: "F5B942"))
                .frame(width: 9, height: 9)
            VStack(alignment: .leading, spacing: 4) {
                Text(bluetooth.connectedName ?? (bluetooth.isScanning ? "Searching for devices…" : "Device not connected"))
                    .font(.system(size: 13, weight: .semibold))
                Text(bluetooth.connectedName == nil ? "Bluetooth discovery preview" : "Bluetooth connected")
                    .font(.system(size: 11)).foregroundStyle(.secondary)
            }
            Spacer()
            Button(bluetooth.isScanning ? "STOP" : "SCAN") {
                bluetooth.isScanning ? bluetooth.stopScan() : bluetooth.startScan()
            }
            .font(.system(size: 11, weight: .bold))
            .padding(.horizontal, 13).padding(.vertical, 10)
            .background(Color(hex: "302344"), in: RoundedRectangle(cornerRadius: 11))
        }
        .padding(14).background(Color(hex: "151722"), in: RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(Color.white.opacity(0.08)))
    }

    private var homePage: some View {
        VStack(alignment: .leading, spacing: 22) {
            connectionCard
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 25).fill(
                    LinearGradient(colors: [Color(hex: "24213B"), Color(hex: "141521")],
                                   startPoint: .topLeading, endPoint: .bottomTrailing)
                )
                HStack {
                    VStack(alignment: .leading, spacing: 10) {
                        Text("MAKE IT YOURS").font(.system(size: 10, weight: .bold)).tracking(2).foregroundStyle(.secondary)
                        Text("Light up\nyour style.").font(.system(size: 27, weight: .bold, design: .rounded))
                        Text("Customize colors, patterns\nand your helmet display.")
                            .font(.system(size: 12)).foregroundStyle(Color(hex: "B7B6CA"))
                        Button { tab = .colors } label: {
                            Label("Explore effects", systemImage: "arrow.up.right")
                                .font(.system(size: 12, weight: .bold))
                                .padding(.horizontal, 14).padding(.vertical, 11)
                                .background(LinearGradient(colors: [Color(hex: "8959F8"), Color(hex: "5D72F6")], startPoint: .leading, endPoint: .trailing), in: RoundedRectangle(cornerRadius: 12))
                        }
                    }
                    Spacer(minLength: 0)
                    Image("LEDHelmet").resizable().scaledToFit().frame(width: 112, height: 140)
                }
                .padding(20)
            }
            .frame(minHeight: 220)
            sectionTitle("Studio", trailing: "Choose a mode")
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                studioTile("Color & effects", subtitle: "Colors, brightness, patterns", icon: "paintpalette.fill", color: Color(hex: "9B7BFF")) { tab = .colors }
                studioTile("Animations", subtitle: "Display patterns", icon: "sparkles", color: Color(hex: "4CDDD3")) { tab = .animations }
                studioTile("DIY Studio", subtitle: "Custom text display", icon: "textformat", color: Color(hex: "FF7BA5")) { tab = .diy }
                studioTile("Music mode", subtitle: "Audio and light effects", icon: "music.note", color: Color(hex: "FFC45C")) { tab = .animations }
            }
            sectionTitle("Quick color", trailing: selectedColor.hexString)
            colorPalette
            Text("Native iOS prototype. Hardware commands depend on identifying the original controller protocol.")
                .font(.system(size: 10)).foregroundStyle(.secondary).multilineTextAlignment(.center)
                .frame(maxWidth: .infinity).padding(.top, 2)
        }
    }

    private var colorsPage: some View {
        VStack(alignment: .leading, spacing: 20) {
            pageHeading("Color & effects", subtitle: "LIGHT CONTROL")
            VStack(alignment: .leading, spacing: 20) {
                HStack(spacing: 14) {
                    ColorPicker("Custom color", selection: $selectedColor, supportsOpacity: false).labelsHidden().scaleEffect(1.35).frame(width: 42, height: 42)
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Custom color").font(.system(size: 14, weight: .semibold))
                        Text(selectedColor.hexString).font(.system(size: 11, design: .monospaced)).foregroundStyle(.secondary)
                    }
                    Spacer()
                }
                colorPalette
                valueSlider("Brightness", value: $brightness)
                valueSlider("Effect speed", value: $speed)
            }.padding(17).darkCard()
            Text("EFFECTS").font(.system(size: 10, weight: .bold)).tracking(2).foregroundStyle(.secondary)
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 9) {
                    ForEach(["Static", "Breathing", "Rainbow", "Strobe", "Flow"], id: \.self) { effect in
                        Button { selectedEffect = effect } label: {
                            Text(effect).font(.system(size: 12, weight: .semibold))
                                .padding(.horizontal, 15).padding(.vertical, 12)
                                .background(selectedEffect == effect ? Color(hex: "50326C") : Color(hex: "1A1C28"), in: RoundedRectangle(cornerRadius: 12))
                                .overlay(RoundedRectangle(cornerRadius: 12).stroke(selectedEffect == effect ? Color(hex: "8C63F4") : Color.white.opacity(0.08)))
                        }
                    }
                }
            }
            VStack(alignment: .leading, spacing: 12) {
                HStack { Text("Live preview").font(.system(size: 14, weight: .semibold)); Spacer(); Text(selectedEffect).font(.system(size: 11)).foregroundStyle(.secondary) }
                RoundedRectangle(cornerRadius: 15).fill(selectedEffect == "Rainbow" ? AnyShapeStyle(LinearGradient(colors: [.red, .orange, .yellow, .green, .cyan, .blue, .purple], startPoint: .leading, endPoint: .trailing)) : AnyShapeStyle(selectedColor))
                    .frame(height: 78).opacity(brightness)
                    .shadow(color: selectedColor.opacity(0.5), radius: 18)
            }.padding(17).darkCard()
            Button { bluetooth.sendPreviewNotice() } label: {
                Label("Apply to device", systemImage: "dot.radiowaves.left.and.right")
                    .frame(maxWidth: .infinity).padding(14)
                    .background(Color(hex: "6843B5"), in: RoundedRectangle(cornerRadius: 14))
            }
        }
    }

    private var animationsPage: some View {
        VStack(alignment: .leading, spacing: 18) {
            pageHeading("Animations", subtitle: "DISPLAY LIBRARY")
            Text("Choose an animation to preview").font(.system(size: 13)).foregroundStyle(.secondary)
            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 12) {
                ForEach(1...6, id: \.self) { n in
                    Button { selectedEffect = "Pattern \(n)" } label: {
                        VStack(alignment: .leading, spacing: 12) {
                            ZStack {
                                RoundedRectangle(cornerRadius: 14).fill(Color(hex: "0D0F18"))
                                Image(systemName: ["waveform.path", "sparkles", "bolt.fill", "rainbow", "heart.fill", "circle.hexagongrid.fill"][(n-1)%6])
                                    .font(.system(size: 35)).foregroundStyle(palette[(n-1)%palette.count])
                                    .shadow(color: palette[(n-1)%palette.count].opacity(0.6), radius: 15)
                            }.frame(height: 105)
                            Text("Pattern \(String(format: "%02d", n))").font(.system(size: 13, weight: .semibold))
                        }.padding(10).frame(maxWidth: .infinity, alignment: .leading).darkCard()
                    }.buttonStyle(.plain)
                }
            }
            Text("Selecting a pattern currently changes the preview only. Hardware playback needs the controller's command format.")
                .font(.system(size: 11)).foregroundStyle(.secondary)
        }
    }

    private var diyPage: some View {
        VStack(alignment: .leading, spacing: 18) {
            pageHeading("DIY Studio", subtitle: "CREATE")
            VStack(alignment: .leading, spacing: 16) {
                Text("TEXT DISPLAY").font(.system(size: 10, weight: .bold)).tracking(2).foregroundStyle(.secondary)
                TextField("Type your message", text: $customText).textInputAutocapitalization(.characters).padding(14).background(Color.black.opacity(0.25), in: RoundedRectangle(cornerRadius: 12))
                ColorPicker("Text color", selection: $selectedColor, supportsOpacity: false)
                ZStack {
                    RoundedRectangle(cornerRadius: 13).fill(Color.black.opacity(0.6))
                    Text(customText.isEmpty ? "YOUR TEXT" : customText.uppercased())
                        .font(.system(size: 22, weight: .heavy, design: .rounded)).tracking(2)
                        .foregroundStyle(selectedColor).multilineTextAlignment(.center).padding()
                }.frame(minHeight: 110)
                Button { bluetooth.sendPreviewNotice() } label: {
                    Label("Save design preview", systemImage: "square.and.arrow.down")
                        .frame(maxWidth: .infinity).padding(13).background(Color(hex: "6843B5"), in: RoundedRectangle(cornerRadius: 12))
                }
            }.padding(17).darkCard()
        }
    }

    private var colorPalette: some View {
        HStack(spacing: 12) {
            ForEach(palette.indices, id: \.self) { index in
                Button { selectedColor = palette[index] } label: {
                    Circle().fill(palette[index]).frame(width: 29, height: 29)
                        .overlay(Circle().stroke(Color.white.opacity(0.25), lineWidth: 1))
                        .overlay(Circle().stroke(Color.white, lineWidth: selectedColor.hexString == palette[index].hexString ? 2 : 0).padding(-4))
                }.buttonStyle(.plain)
            }
            Spacer(minLength: 0)
        }.padding(.vertical, 4)
    }

    private var tabBar: some View {
        HStack(spacing: 0) {
            ForEach(StudioTab.allCases, id: \.self) { item in
                Button { tab = item } label: {
                    VStack(spacing: 5) {
                        Image(systemName: item.icon).font(.system(size: 19, weight: .semibold))
                        Text(item.rawValue).font(.system(size: 10, weight: .medium))
                    }.foregroundStyle(tab == item ? Color(hex: "C3A5FF") : Color(hex: "777C94"))
                    .frame(maxWidth: .infinity).padding(.vertical, 8)
                }.buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 12).padding(.top, 8)
        .background(.ultraThinMaterial)
        .overlay(alignment: .top) { Rectangle().fill(Color.white.opacity(0.08)).frame(height: 1) }
    }

    private func sectionTitle(_ title: String, trailing: String) -> some View {
        HStack { Text(title).font(.system(size: 17, weight: .bold)); Spacer(); Text(trailing).font(.system(size: 11)).foregroundStyle(.secondary) }
    }
    private func pageHeading(_ title: String, subtitle: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(subtitle).font(.system(size: 10, weight: .bold)).tracking(2).foregroundStyle(.secondary)
            Text(title).font(.system(size: 29, weight: .bold, design: .rounded))
        }.padding(.top, 10)
    }
    private func studioTile(_ title: String, subtitle: String, icon: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(alignment: .leading, spacing: 9) {
                Image(systemName: icon).font(.system(size: 25, weight: .medium)).foregroundStyle(color).frame(height: 36)
                Text(title).font(.system(size: 13, weight: .bold)).foregroundStyle(.white)
                Text(subtitle).font(.system(size: 10)).foregroundStyle(.secondary).multilineTextAlignment(.leading)
            }.frame(maxWidth: .infinity, minHeight: 112, alignment: .leading).padding(14).darkCard()
        }.buttonStyle(.plain)
    }
    private func valueSlider(_ title: String, value: Binding<Double>) -> some View {
        VStack(spacing: 8) {
            HStack { Text(title).font(.system(size: 12)); Spacer(); Text("\(Int(value.wrappedValue * 100))%").font(.system(size: 12, weight: .semibold)).foregroundStyle(.secondary) }
            Slider(value: value, in: 0.01...1)
        }
    }
}

final class BluetoothManager: NSObject, ObservableObject, CBCentralManagerDelegate {
    @Published var isScanning = false
    @Published var connectedName: String?
    @Published var showAlert = false
    @Published var alertMessage = ""
    private var central: CBCentralManager?
    private var found: [UUID: CBPeripheral] = [:]

    func startScan() {
        if central == nil { central = CBCentralManager(delegate: self, queue: .main) }
        else if central?.state == .poweredOn { scanNow() }
    }
    func stopScan() { central?.stopScan(); isScanning = false }
    private func scanNow() {
        found.removeAll()
        isScanning = true
        central?.scanForPeripherals(withServices: nil, options: [CBCentralManagerScanOptionAllowDuplicatesKey: false])
        DispatchQueue.main.asyncAfter(deadline: .now() + 12) { [weak self] in
            guard let self, self.isScanning else { return }
            self.stopScan()
            if self.found.isEmpty {
                self.alertMessage = "No Bluetooth devices were found during this scan. Turn on your controller and try again. The original controller's service and command protocol still needs to be identified before controls can work."
                self.showAlert = true
            } else {
                let names = self.found.values.compactMap { $0.name }.prefix(8).joined(separator: ", ")
                self.alertMessage = "Found nearby Bluetooth device(s): \(names). Device selection and RGB command support are not yet implemented."
                self.showAlert = true
            }
        }
    }
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        DispatchQueue.main.async {
            switch central.state {
            case .poweredOn: self.scanNow()
            case .poweredOff:
                self.isScanning = false; self.alertMessage = "Turn on Bluetooth in iPhone Settings."; self.showAlert = true
            case .unauthorized:
                self.isScanning = false; self.alertMessage = "Allow Bluetooth access for ShiningRGB in Settings."; self.showAlert = true
            default: break
            }
        }
    }
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        found[peripheral.identifier] = peripheral
    }
    func sendPreviewNotice() {
        alertMessage = "This iOS prototype can preview the controls, but it does not yet send RGB commands. The original controller's Bluetooth/Wi-Fi protocol must be identified first."
        showAlert = true
    }
}

extension View {
    func darkCard() -> some View {
        self.background(LinearGradient(colors: [Color(hex: "191B28"), Color(hex: "12131C")], startPoint: .topLeading, endPoint: .bottomTrailing), in: RoundedRectangle(cornerRadius: 19))
            .overlay(RoundedRectangle(cornerRadius: 19).stroke(Color.white.opacity(0.08)))
    }
}
extension Color {
    init(hex: String) {
        let value = UInt64(hex, radix: 16) ?? 0
        self.init(.sRGB, red: Double((value >> 16) & 0xFF)/255, green: Double((value >> 8) & 0xFF)/255, blue: Double(value & 0xFF)/255, opacity: 1)
    }
    var hexString: String {
        let components = UIColorComponents(color: self)
        return String(format: "#%02X%02X%02X", components.r, components.g, components.b)
    }
}
private struct UIColorComponents {
    let r: Int; let g: Int; let b: Int
    init(color: Color) {
        #if canImport(UIKit)
        let ui = UIColor(color)
        var red: CGFloat = 0, green: CGFloat = 0, blue: CGFloat = 0, alpha: CGFloat = 0
        ui.getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        r = Int(red * 255); g = Int(green * 255); b = Int(blue * 255)
        #else
        r = 0; g = 0; b = 0
        #endif
    }
}
