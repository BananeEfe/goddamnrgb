ShiningRGB — native iOS starter project

This is a native SwiftUI iOS project, not HTML. It contains a recreated ShiningRGB-style interface, color/effect previews, DIY text preview, an animation gallery, and a CoreBluetooth discovery scaffold.

IMPORTANT
- This is source code, not an installable .ipa. It must be built and signed with Xcode on a Mac.
- Bluetooth scanning is included as a starting point, but connecting to a discovered device and sending RGB commands are NOT implemented.
- The original APK's Bluetooth service/characteristic IDs and command protocol must be identified before actual hardware control can work. This project does not pretend otherwise.
- Bundle identifier is com.example.ShiningRGB; change it to a unique identifier in Xcode before installing.
- Open ShiningRGB.xcodeproj in Xcode, select your iPhone as the run destination, choose your Apple development team under Signing & Capabilities, then Run.
- Requires Xcode on macOS and a supported iOS device. App Store distribution requires Apple's separate review and distribution process.

The included graphics were extracted from the APK supplied in this chat.
